# Pharmacy-Website
A project in which a fully functional website was built on HTML, CSS, PHP, and PHPMyAdmin SQL database. 
